// /* global chrome */
// import React, { Component } from "react";
// import LinkButton from "../../styledComponents/linkButton";
// // if (typeof(chrome) !== 'undefined'){
// //   const download = require("../../../download");
// // }

// class DownloadAttachments extends Component {
//   state = {};
//   download = () => {
//     if (typeof(download) !== 'undefined'){
//       download.startDownload(this.props.unitData,this.shortUnitName);
//     }
//   }
//   render() {
//     return (
//       <div onClick={this.download} className="flex flex-col">
//         <LinkButton
//           text={
//             <div>
//               Download All&emsp;<i class="fas fa-download" />
//             </div>
//           }
//         />
//       </div>
//     );
//   }
// }

// export default DownloadAttachments;
