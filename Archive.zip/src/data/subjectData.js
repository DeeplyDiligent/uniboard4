class SubjectData{
  
}
const subjectData = new SubjectData();
//  Object.freeze(database);
export default subjectData;