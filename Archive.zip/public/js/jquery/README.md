jQuery Component
================

Shim repository for jQuery.
